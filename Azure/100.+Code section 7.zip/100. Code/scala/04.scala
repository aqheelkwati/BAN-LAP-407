@main def dataApp() =
  var i=1
  while(i <= 10) {
    println("The value of i is " + i)
    i=i+1
  }