@main def dataApp() =
  var i=12
  if (i<10)
    {
      println("The number is less than 10")
    }
  else
     println("The number is more than 10")




