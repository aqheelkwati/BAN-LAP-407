@main def dataApp() =
  var i=0
  for(i<-1 to 10)
      println("The value of i is " + i)