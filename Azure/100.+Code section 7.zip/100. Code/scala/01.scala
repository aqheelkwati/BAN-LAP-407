@main def dataApp() =
  println("Hello world!")