import scala.util.Random
@main def dataApp() = 
  println(addNumbers(5,6))    

  def addNumbers(x:Int,y:Int) : Int =
  return(x+y)