# Python - If construct

# Here we will look at a control flow statement

x=10
if x>=10:
    print('Greater or equal to 10')
else:
    print('Less than 10')