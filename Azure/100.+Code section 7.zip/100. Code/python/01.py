# Python - A simple program

# This is a simple string data tyope
str="Hello World"

# This is a integer data tyope
i=1

# This is a float data tyope
num=20.6

# This is a boolean data tyope
status=True

print(str)
print(i)
print(num)
print(status)