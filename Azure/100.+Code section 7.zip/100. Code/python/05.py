# Python - Functions

def add(x,y):    
    return x+y

print("The sum is " + str(add(2,3)))
print("The sum is " + add("Hello ","World"))