-- Azure Data Factory and Incremental loads

CREATE TABLE WebMetrics
(
    Average decimal,
    Metrictime datetime,
    MetricName varchar(200)
)